##Adobe File Version: 1.000
-------------------------------------------------------------------------------

                File name:    Adobe ReadMe for Unicode 3.0

                Date:         30 March 1999

-------------------------------------------------------------------------------



The document "Unicode and Glyph Names," at:


 http://partners.adobe.com/asn/developer/typeforum/unicodegn.html

describes Adobe's PostScript glyph naming conventions in the context of
Unicode and also contains links to the following 3 database files:

 "The Adobe Glyph List" (AGL), which maps approximately 1000 glyph names to
   standard or Corporate Use subarea Unicode values.
 "Unicode's Corporate Use Subarea as used by Adobe."
 "Zapf Dingbats Glyph Names and Unicode Values."

-------------------------------------------------------------------------------

The 3 files in the current directory:

 stdenc.txt
 symbol.txt
 zdingbat.txt

were originally provided by the Unicode Consortium for use by NeXT
implementations with DPS, and continue to be provided for compatibility with
those implementations. All others should refer to the files on Adobe.com
mentioned above.

-------------------------------------------------------------------------------
